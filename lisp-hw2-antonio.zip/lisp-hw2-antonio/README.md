# Lisp Programming Assignment (UHCL)

This repository contains my Lisp programming assignment for the **Programming Language Concepts** course at the University of Houston–Clear Lake.

---

## Project Overview
The assignment demonstrates functional programming concepts using **Common Lisp**. It explores recursion, list processing, and symbolic computation — key features of the Lisp family of languages.

---

## Components

**Source (`src/`)**
- Contains the Lisp program files (.lisp).
- Implements the assignment requirements with functional programming techniques.

**Documentation (`docs/`)**
- Includes the original assignment brief and supporting materials.

---

## How to Use

Clone the repository:
```bash
gh repo clone <YOUR_USERNAME>/lisp-hw2-antonio
```

Run the Lisp code (using SBCL or CLISP):
```bash
cd src
sbcl --load file.lisp
```
or
```bash
clisp file.lisp
```

> Replace `file.lisp` with the specific source file you want to run.

---

## Requirements
- Common Lisp implementation (SBCL recommended, or CLISP)
- Terminal/command line access

---

## Project Structure
```
src/            # Lisp source code (.lisp)
docs/           # Assignment PDF/briefs
```

---

## License
This project is for educational purposes as part of coursework at UHCL.
